# GAROU Audio — GitHub Actions Build

1. Upload all files in this folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build GAROU Audio**.
4. Press **Run workflow**.
5. When the job finishes, open the run and download the **libgarou_audio** artifact.

The workflow installs Android NDK r25c automatically and runs `ndk-build`.
