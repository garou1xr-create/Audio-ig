LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE    := garou_audio
LOCAL_SRC_FILES := garou_audio.cpp
LOCAL_LDLIBS    := -llog -landroid
LOCAL_CFLAGS    := -O2 -std=c++17
include $(BUILD_SHARED_LIBRARY)
