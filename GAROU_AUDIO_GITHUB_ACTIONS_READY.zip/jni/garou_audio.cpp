// GAROU Audio Effects - Native core
// Effects: Hard Gain, Heavy Bass, Echo, Burr/Stutter
// Self-monitoring OFF (process only outgoing mic path)

#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <cstring>
#include <vector>
#include <atomic>

#define LOG_TAG "GAROU_AUDIO"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static std::atomic<bool> g_gain_on{true};
static std::atomic<bool> g_bass_on{true};
static std::atomic<bool> g_echo_on{false};
static std::atomic<bool> g_burr_on{false};

static std::atomic<float> g_gain{2.5f};      // Hard loud
static std::atomic<float> g_bass{1.8f};
static std::atomic<float> g_echo_decay{0.45f};
static std::atomic<float> g_burr_rate{0.12f};

// Simple echo buffer (mono)
static std::vector<float> echo_buf(8000, 0.f);
static size_t echo_pos = 0;

// Burr state
static int burr_counter = 0;

extern "C" {

JNIEXPORT void JNICALL
Java_com_garou_audio_GarouAudio_setEffect(JNIEnv*, jclass, jint effect, jboolean enabled, jfloat intensity) {
    switch (effect) {
        case 0: // Gain
            g_gain_on = enabled;
            g_gain = std::max(0.5f, std::min(intensity, 6.0f));
            break;
        case 1: // Bass
            g_bass_on = enabled;
            g_bass = std::max(0.5f, std::min(intensity, 4.0f));
            break;
        case 2: // Echo
            g_echo_on = enabled;
            g_echo_decay = std::max(0.1f, std::min(intensity, 0.9f));
            break;
        case 3: // Burr
            g_burr_on = enabled;
            g_burr_rate = std::max(0.02f, std::min(intensity, 0.4f));
            break;
    }
    LOGI("Effect %d enabled=%d intensity=%.2f", effect, enabled, intensity);
}

// Process 16-bit PCM mono/stereo interleaved
JNIEXPORT void JNICALL
Java_com_garou_audio_GarouAudio_processBuffer(JNIEnv* env, jclass, jshortArray jdata, jint channels) {
    if (!jdata) return;
    jsize len = env->GetArrayLength(jdata);
    jshort* data = env->GetShortArrayElements(jdata, nullptr);
    if (!data) return;

    for (jsize i = 0; i < len; i += channels) {
        for (int c = 0; c < channels && (i + c) < len; ++c) {
            float s = data[i + c] / 32768.0f;

            // Hard Gain
            if (g_gain_on) {
                s *= g_gain;
            }

            // Simple bass boost (low shelf approximation)
            if (g_bass_on) {
                static float prev = 0.f;
                float low = 0.7f * prev + 0.3f * s;
                prev = low;
                s = s + (low * (g_bass - 1.0f));
            }

            // Echo
            if (g_echo_on) {
                float delayed = echo_buf[echo_pos];
                s += delayed * g_echo_decay;
                echo_buf[echo_pos] = s;
                echo_pos = (echo_pos + 1) % echo_buf.size();
            }

            // Burr / Stutter (drop samples periodically)
            if (g_burr_on) {
                burr_counter++;
                int period = (int)(1.0f / g_burr_rate);
                if (period > 0 && (burr_counter % period) < (period / 4)) {
                    s *= 0.15f; // stutter dip
                }
            }

            // Soft clip
            if (s > 1.0f) s = 1.0f;
            if (s < -1.0f) s = -1.0f;

            data[i + c] = (jshort)(s * 32767.0f);
        }
    }

    env->ReleaseShortArrayElements(jdata, data, 0);
}

JNIEXPORT void JNICALL
Java_com_garou_audio_GarouAudio_reset(JNIEnv*, jclass) {
    std::fill(echo_buf.begin(), echo_buf.end(), 0.f);
    echo_pos = 0;
    burr_counter = 0;
    LOGI("Reset buffers");
}

} // extern C
