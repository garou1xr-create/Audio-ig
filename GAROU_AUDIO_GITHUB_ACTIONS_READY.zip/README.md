# GAROU AUDIO INJECT MODULE

Standalone native audio effects library for Virtual / Instagram clone.

## Effects
- Hard Gain / Loud
- Heavy Bass
- Echo
- Burr / Stutter

Each effect: ON/OFF + intensity.
Self-monitoring OFF (only processes mic buffer going out).

## Structure
```
GAROU_AUDIO_INJECT/
├── jni/
│   ├── garou_audio.cpp
│   ├── Android.mk
│   └── Application.mk
├── java/com/garou/audio/
│   ├── GarouAudio.java
│   └── FloatingAudioService.java
├── res/layout/floating_audio_panel.xml
└── README.md
```

## Build native .so
```bash
ndk-build -C jni
# output: libs/arm64-v8a/libgarou_audio.so
#         libs/armeabi-v7a/libgarou_audio.so
```

## How to use with Virtual

1. Build `libgarou_audio.so`
2. Copy into Virtual's lib folder or inject via Virtual's plugin/hook system
3. Register `FloatingAudioService` in the host/Virtual process
4. Request `SYSTEM_ALERT_WINDOW` permission
5. Start service → floating panel appears
6. Call `GarouAudio.processBuffer(short[] pcm, channels)` from the mic read path

## Auto-inject note
Because the provided Virtual ZIP has no smali / full source, automatic injection into every cloned app cannot be patched inside that dump.

To make Virtual auto-inject:
- You need full Virtual source (with smali or Android Studio project)
- Then hook `AudioRecord.read` / OpenSL callback inside Virtual's app process launcher
- Load `libgarou_audio.so` and call `processBuffer` on every mic frame

This module gives you the complete audio core + floating UI ready for that integration.

## Permissions needed
```xml
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
```

## Profile / Clone settings
`FloatingAudioService` saves per-effect state in SharedPreferences (`garou_audio_prefs`).
You can namespace the prefs name per Virtual user/clone ID if needed.

GAROU
