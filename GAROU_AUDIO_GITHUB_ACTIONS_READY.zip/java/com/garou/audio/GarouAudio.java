package com.garou.audio;

public class GarouAudio {
    static {
        try {
            System.loadLibrary("garou_audio");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }

    // effect: 0=Gain, 1=Bass, 2=Echo, 3=Burr
    public static native void setEffect(int effect, boolean enabled, float intensity);
    public static native void processBuffer(short[] data, int channels);
    public static native void reset();
}
