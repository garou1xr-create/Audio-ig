package com.garou.audio;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.content.SharedPreferences;

public class FloatingAudioService extends Service {
    private WindowManager windowManager;
    private View floatingView;
    private SharedPreferences prefs;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("garou_audio_prefs", MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Minimal floating panel (you can replace with real layout inflate)
        floatingView = LayoutInflater.from(this).inflate(
                getResources().getIdentifier("floating_audio_panel", "layout", getPackageName()), null);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 200;

        // Drag
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int lastX, lastY;
            private float touchX, touchY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = params.x; lastY = params.y;
                        touchX = event.getRawX(); touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = lastX + (int) (event.getRawX() - touchX);
                        params.y = lastY + (int) (event.getRawY() - touchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });

        bindControls(floatingView);
        loadSettings();
        try {
            windowManager.addView(floatingView, params);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void bindControls(View root) {
        // Expected IDs in layout: switch_gain, seek_gain, switch_bass, seek_bass,
        // switch_echo, seek_echo, switch_burr, seek_burr, btn_close
        setupEffect(root, "switch_gain", "seek_gain", 0, 2.5f);
        setupEffect(root, "switch_bass", "seek_bass", 1, 1.8f);
        setupEffect(root, "switch_echo", "seek_echo", 2, 0.45f);
        setupEffect(root, "switch_burr", "seek_burr", 3, 0.12f);

        int closeId = getResources().getIdentifier("btn_close", "id", getPackageName());
        View close = root.findViewById(closeId);
        if (close != null) {
            close.setOnClickListener(v -> stopSelf());
        }
    }

    private void setupEffect(View root, String switchName, String seekName, int effectId, float def) {
        int swId = getResources().getIdentifier(switchName, "id", getPackageName());
        int skId = getResources().getIdentifier(seekName, "id", getPackageName());
        Switch sw = root.findViewById(swId);
        SeekBar sk = root.findViewById(skId);
        if (sw == null || sk == null) return;

        boolean on = prefs.getBoolean("eff_" + effectId + "_on", effectId <= 1);
        float intensity = prefs.getFloat("eff_" + effectId + "_val", def);
        sw.setChecked(on);
        sk.setProgress((int) (intensity * 100));
        GarouAudio.setEffect(effectId, on, intensity);

        sw.setOnCheckedChangeListener((b, checked) -> {
            float v = sk.getProgress() / 100f;
            GarouAudio.setEffect(effectId, checked, v);
            prefs.edit().putBoolean("eff_" + effectId + "_on", checked).apply();
        });
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                float v = progress / 100f;
                GarouAudio.setEffect(effectId, sw.isChecked(), v);
                prefs.edit().putFloat("eff_" + effectId + "_val", v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void loadSettings() {
        // already applied in setupEffect
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null && windowManager != null) {
            try { windowManager.removeView(floatingView); } catch (Exception ignored) {}
        }
    }
}
